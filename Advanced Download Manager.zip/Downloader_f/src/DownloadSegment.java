import java.io.BufferedInputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;


class DownloadSegment extends Thread{

	private long startingByte;
	private long endingByte;
	private String filename;
	private String fileURL;
	GUI gui;
	int row,col;
	String state="resume";
	boolean cancelState=false;
	boolean singleFileDownload=false;
	
	DownloadSegment(GUI gui,long startingByte,long endingByte,String filename,String fileURL,int row,int col,boolean singleFileDownload){
		this.startingByte=startingByte;
		this.endingByte=endingByte;
		this.filename=filename;
		this.fileURL=fileURL;
		this.gui=gui;
		this.row=row;
		this.col=col;
		this.singleFileDownload=singleFileDownload;
		//System.out.println(startingByte+", "+endingByte);
	}

	void changeState(String state){
		this.state=state;
	}
	void cancel(){
		cancelState=true;
	}

	int percent=0;

	//void updateRow(){
	//	gui.updateRow(row,col,(int)percent);
	//}

	
	
	public void run(){

	/*	new Thread(new Runnable(){
	        	public void run(){
	        		while(true){
	        			updateRow();
	        			try{
	        				Thread.currentThread().sleep(1000);
	        			}catch(Exception e){}
	        			if(percent==100)
	        				break;
	        		}
	        	}
	 	}).start();
*/
		try{
			URL url = new URL(fileURL);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	      
		    if(!singleFileDownload){
		        if(endingByte!=-1)
		        	connection.setRequestProperty("Range", "bytes=" + startingByte + "-" + endingByte); 
		        else
		        	connection.setRequestProperty("Range", "bytes=" + startingByte + "-" + ""); //is endingByte is empty string http request all the bytes till EOF from given starting byte.
		        connection.connect();
		        if (connection.getResponseCode() != 206) {   // http return 206 as signal of OK if request is send with range header
		            System.out.println("Error return code != 206");
		        }
	    	}

	        BufferedInputStream in=new BufferedInputStream(connection.getInputStream());
	        RandomAccessFile os=new RandomAccessFile(filename,"rw");

	        long filesize=connection.getContentLengthLong();
	        int readSize=1024*32;
	        byte[] data=new byte[readSize];
	        int i=0;
	        long totalDataRead=0;
	        //long percent=0;
	        os.seek(startingByte);
	        //System.out.println("In run3: "+filesize);

	        


	        while(true) {
	        	if(cancelState){
	        		System.out.println("cancel");
	        		gui.updateRow(row,col,-1);
	        		break;
	        	}
	        		
	        	
	        	if(state.equals("resume")){
		        	if((i=in.read(data,0,readSize))<0)
		        		break;

		        	//System.out.println(i);
		        	totalDataRead=totalDataRead+i;
		        	//System.out.println(i);
		        	os.write(data,0,i);
		        	percent=(int)((totalDataRead*100)/filesize);
		        	//System.out.println("Percent: "+percent);
		        	//System.out.println("Percent: "+(int)percent);
		        	gui.updateRow(row,col,percent);
		        }
		        else{
		        	gui.updateRow(row,col,-2);
		      		Thread.currentThread().sleep(1000);
		        }
		        //System.out.println(state);
	        }
	        os.close();
	        in.close();
	        
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
