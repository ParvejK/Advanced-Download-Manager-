import java.awt.EventQueue;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.UIManager;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JLabel;

import java.awt.Component;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.Enumeration;
import java.util.EventObject;
import java.util.Vector;

import javax.swing.border.TitledBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.JTextArea;
import javax.swing.*;
import javax.swing.table.*;

import java.awt.SystemColor;

class GUI{

	public JFrame frame;
	public JTextField textField;
	Point initialClick;
	public JTable table;
	JPanel panelTable;
	JProgressBar pb[]=new JProgressBar[5];
	DefaultModel model;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.GRAY);
		frame.setBackground(Color.GRAY);
		//frame.setBounds(100, 100, 555, 468);
		frame.setBounds(100, 100, 906, 468);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setUndecorated(true);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(350+437, 32, 106, 55);
		panel.setBackground(Color.GRAY);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JRadioButton radioButton = new JRadioButton("");
		radioButton.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		radioButton.setForeground(Color.WHITE);
		radioButton.setBackground(Color.GRAY);
		radioButton.setBounds(0, 9, 20, 27);
		radioButton.setText("1");
		panel.add(radioButton);
		
		JRadioButton radioButton_1 = new JRadioButton("");
		radioButton_1.setBackground(Color.GRAY);
		radioButton_1.setBounds(20, 3, 21, 25);
		radioButton_1.setText("2");
		panel.add(radioButton_1);
		
		JRadioButton radioButton_2 = new JRadioButton("");
		radioButton_2.setBackground(Color.GRAY);
		radioButton_2.setBounds(40, 0, 21, 25);
		radioButton_2.setText("3");
		panel.add(radioButton_2);
		
		JRadioButton radioButton_3 = new JRadioButton("");
		radioButton_3.setBackground(Color.GRAY);
		radioButton_3.setBounds(60, 3, 21, 25);
		radioButton_3.setText("4");
		panel.add(radioButton_3);
		
		JRadioButton radioButton_4 = new JRadioButton("");
		radioButton_4.setBackground(Color.GRAY);
		radioButton_4.setBounds(80, 11, 21, 25);
		radioButton_4.setText("5");
		panel.add(radioButton_4);
		
		ButtonGroup butgr=new ButtonGroup();
		butgr.add(radioButton);
		butgr.add(radioButton_1);
		butgr.add(radioButton_2);
		butgr.add(radioButton_3);
		butgr.add(radioButton_4);
		radioButton.setSelected(true);
		
		JLabel lblSpeed = new JLabel("speed");
		lblSpeed.setForeground(Color.WHITE);
		lblSpeed.setBounds(24, 30, 48, 16);
		panel.add(lblSpeed);
		lblSpeed.setFont(new Font("Lucida Handwriting", Font.BOLD, 13));
		
		JPanel panel_1 = new JPanel();
		//panel_1.setBounds(0, 0, 555, 30);
		panel_1.setBounds(0, 0, 906, 30);
		panel_1.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				Point p=frame.getLocation();
				//System.out.println((p.x+e.getX()-initialClick.x)+" "+(p.y+e.getY()-initialClick.y));
				frame.setLocation(p.x+e.getX()-initialClick.x, p.y+e.getY()-initialClick.y);
			}
		});
		panel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				initialClick=e.getPoint();
			}
		});
		
		panel_1.setBackground(Color.DARK_GRAY);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnClose = new JButton("");
		btnClose.setBackground(Color.DARK_GRAY);
		btnClose.setIconTextGap(0);
		btnClose.setIcon(new ImageIcon("abc2.png"));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				System.exit(0);
			}
		});
		btnClose.setBounds(350+513, 2, 40, 27);
		panel_1.add(btnClose);
		
		JButton btnMin = new JButton("");
		btnMin.setBackground(Color.DARK_GRAY);
		btnMin.setIcon(new ImageIcon("abc4.png"));
		btnMin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setState(JFrame.ICONIFIED);
			}
		});
		btnMin.setBounds(350+482, 2, 29, 27);
		panel_1.add(btnMin);
		
		JLabel lblRapidDownloader = new JLabel("Advanced Download Manager");
		lblRapidDownloader.setFont(new Font("Castellar", Font.PLAIN, 24));
		lblRapidDownloader.setForeground(Color.WHITE);
		lblRapidDownloader.setBounds(186, 2, 815, 27);
		panel_1.add(lblRapidDownloader);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(0, 32, 425, 49);
		panel_2.setBackground(Color.GRAY);
		frame.getContentPane().add(panel_2);
		panel_2.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(48, 15, 270, 25);
		panel_2.add(textField);
		textField.setColumns(10);
		
		JLabel lblUrl = new JLabel("URL:");
		lblUrl.setForeground(Color.WHITE);
		lblUrl.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblUrl.setBounds(12, 15, 39, 25);
		panel_2.add(lblUrl);
		

		Vector<ManageDownload> downloadList=new Vector<ManageDownload>();
		

		JButton btnAdd = new JButton("Add");
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("hello in add");
				String s=getAccelerationFactor(butgr);
				int accelerationFactor=Integer.parseInt(s);
				if(!textField.getText().equals("")){
					ManageDownload obj = new ManageDownload(GUI.this,textField.getText(),accelerationFactor);
					obj.start();
					downloadList.add(obj);
				}
				//new SingleFileDownload(GUI.this,textField.getText()).start();
			}
		});
		btnAdd.setBounds(331, 15, 71, 25);
		panel_2.add(btnAdd);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setForeground(Color.WHITE);
		scrollPane.setBackground(Color.DARK_GRAY);
		//scrollPane.setBounds(3, 90, 549, 375);
		scrollPane.setBounds(3, 90, 900, 375);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setRowSelectionAllowed(false);
		table.setFont(new Font("Tahoma", Font.PLAIN, 15));
		table.setForeground(Color.BLACK);
		table.setBackground(new Color(220, 220, 220));
		
	/*	DefaultTableModel model=new DefaultTableModel(
			new Object[][] {
			},
			new String[] {"File","Progress","Action"
			}
		){
			/**
			 * 
			 */
			/*private static final long serialVersionUID = 1L;
			boolean[] columnEditables = new boolean[] {
					false, false, false
				};
				public boolean isCellEditable(int row, int column) {
					return columnEditables[column];
				}
				
				public void addRow1(String fileName,int n){
					panelTable=new JPanel();
					panelTable.setLayout(new GridLayout(1,2));
					for(int i=0;i<n;i++){
						pb[i]=new JProgressBar(0,100);
						panel.add(pb[i]);
					}
					Object value[]=new Object[]{fileName,panelTable,"Action"};
					addRow(value);
				}
				
				
			};*/
		model=new DefaultModel();
		table.setModel(model);
		table.getColumnModel().getColumn(0).setResizable(false);
		table.getColumnModel().getColumn(0).setPreferredWidth(125);
		table.getColumnModel().getColumn(1).setResizable(false);
		table.getColumnModel().getColumn(1).setPreferredWidth(400);
		table.getColumnModel().getColumn(2).setResizable(false);
		table.getColumnModel().getColumn(2).setPreferredWidth(100);
		table.getColumnModel().getColumn(3).setResizable(false);
		table.getColumnModel().getColumn(3).setPreferredWidth(75);
		table.getColumnModel().getColumn(4).setResizable(false);
		table.getColumnModel().getColumn(4).setPreferredWidth(75);
		
		table.getColumnModel().getColumn(1).setCellRenderer(new CELL_RENDERER1());
		//table.getColumnModel().getColumn(1).setCellEditor(new CELL_EDITOR());

		//table.getColumnModel().getColumn(3).setCellRenderer(new CELL_RENDERER2());
		//table.getColumnModel().getColumn(3).setCellEditor(new ButtonEditor(new JCheckBox()));

		//Alignment
		DefaultTableCellRenderer centerRenderer1 = new DefaultTableCellRenderer();
		centerRenderer1.setHorizontalAlignment( JLabel.RIGHT );
		table.getColumnModel().getColumn(2).setCellRenderer( centerRenderer1 );

		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer(){
			public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int col)
    		{
		        Component cellComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, col);
    			if(col==3 || col==4)
		        	cellComponent.setBackground(new Color(153,153,255));
		     
		        return cellComponent;
    		}
		};
		centerRenderer.setHorizontalAlignment( JLabel.CENTER );
		table.getColumnModel().getColumn(3).setCellRenderer( centerRenderer );
		table.getColumnModel().getColumn(4).setCellRenderer( centerRenderer );

		
		scrollPane.setViewportView(table);
		JTableHeader header = table.getTableHeader();
	    DefaultTableCellRenderer renderer = (DefaultTableCellRenderer)table.getTableHeader().getDefaultRenderer();
	    header.setDefaultRenderer(renderer);
	    renderer.setHorizontalAlignment(JLabel.CENTER);
	    table.setRowHeight(30);




	    table.addMouseListener(new java.awt.event.MouseAdapter(){
            public void mouseClicked(java.awt.event.MouseEvent e){
                int row=table.rowAtPoint(e.getPoint());
                int col= table.columnAtPoint(e.getPoint());
                //JOptionPane.showMessageDialog(null," Value in the cell clicked :"+ " " +table.getValueAt(row,col).toString());
                //JOptionPane.showMessageDialog(null," Value in the cell clicked, row: "+row+",col: "+col);
                if(col==3){
	                String str=(String)table.getValueAt(row,col);
	                if(str.equals("Pause")){
	                	downloadList.get(row).changeState("pause");
	                	table.setValueAt("Resume",row,col);
	                }
	                else if(str.equals("Resume")){
	                	downloadList.get(row).changeState("resume");
	                	table.setValueAt("Pause",row,col);
	                }
            	}
            	if(col==4){
            		String str=(String)table.getValueAt(row,col);
	                if(str.equals("Cancel")){
	                	downloadList.get(row).cancel();
	                	table.setValueAt("Retry",row,col);
	                	table.setValueAt("",row,3);
	                }
	                //else
	                //	table.setValueAt("Cancel",row,col);
            	}
                //System.out.println(" Value in the cell clicked :"+ " " +table.getValueAt(row,col).toString());
            }
        });
	    ///model.addRow(new String[]{"jsfhj","djhf","kjdhf"});
	    
	    //Object value[]= new Object[]{"sahfda",panelTable,btnClose};
	   // model.addRow("shabbir akjdfhakfjhakjfhasjk",1);
	   // model.addRow("shabbir",2);
	   // model.addRow("shabbir",5);
	    
	    
	    //TableCellRenderer buttonRenderer = new JTableButtonRenderer();
        //table.getColumn("Button1").setCellRenderer(buttonRenderer);
        //table.getColumn("Button2").setCellRenderer(buttonRenderer);
	    threadRepaintTable.start();
	}
	public int addDownload(String filename,long filesize,int n){
    	int row=model.addRow(filename,filesize,n);
    	table.repaint();
    	return row;
    }
	
	public void updateRow(int row,int col,int percent){
		//System.out.println("row="+row);
		JPanel p=(JPanel)model.getValueAt(row-1, 1);
		JProgressBar pb=(JProgressBar)p.getComponent(col);
		if(percent==-1)
			pb.setString("Cancelled");
		else if(percent==-2)
			pb.setString("Paused");
		else
			pb.setString(null);
		if(percent!=-1 && percent!=-2)
			pb.setValue(percent);
		if(percent==100)
			pb.setString("Completed");
		//table.repaint();
	}
	
	String getAccelerationFactor(ButtonGroup butgrp){
		for (Enumeration<AbstractButton> buttons = butgrp.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();

            if (button.isSelected()) {
                return button.getText();
            }
        }
		return null;
	}
	
	//Update table in each second
	Thread threadRepaintTable = new Thread(){
	    public void run(){
	      try{
	    	  while(true){
	    		  Thread.sleep(1000);
	    		  table.repaint();
	    	  }
	      }catch(Exception e){
	    	  e.printStackTrace();
	      }
	    }
	 };
	
}




class CELL_RENDERER1 implements TableCellRenderer{
    @Override
    public Component getTableCellRendererComponent(JTable arg0,Object arg1, boolean arg2, boolean arg3, int arg4, int arg5){
        //try{
        //	return (JPanel)arg1;
        //}catch (Exception e) {}
     	return (JPanel)arg1;
    }
}
/*class CELL_RENDERER2 extends JButton implements TableCellRenderer{
    @Override
    public Component getTableCellRendererComponent(JTable arg0,Object arg1, boolean arg2, boolean arg3, int arg4, int arg5){
        //try{
        //	return (JPanel)arg1;
        //}catch (Exception e) {}
     	//return arg1;
     	//JButton button = (JButton)arg1;
            //return (JButton)arg1; 
    	if(getText().equals("Pause"))
    		setText("Pause");
    	else
    		setText("Resume");
    	return this;
    }
}




class CELL_EDITOR implements TableCellEditor{
    @Override
    public boolean stopCellEditing() {
        return false;
    }
    @Override
    public boolean shouldSelectCell(EventObject arg0) {
        return false;
    }
    @Override
    public void removeCellEditorListener(CellEditorListener arg0) {}
    @Override
    public boolean isCellEditable(EventObject arg0) {
         return false;
    }
    @Override
    public Object getCellEditorValue() {
        return null;
    }
    @Override
    public void cancelCellEditing() {}
    @Override
    public void addCellEditorListener(CellEditorListener arg0) {    }   
    @Override
    public Component getTableCellEditorComponent(JTable table, Object value,boolean isSelected, int row, int column) {
        return null;
    }
}
*/


class DefaultModel extends DefaultTableModel{
	public JPanel panelTable;
	public JProgressBar pb[]=new JProgressBar[5];
	private static final long serialVersionUID = 1L;
	
	DefaultModel(){
		addColumn("File");
		addColumn("Progress");
		addColumn("Size(KB)");
		addColumn("");
		addColumn("");
	}
	
	boolean[] columnEditables = new boolean[] {
			false, false, false, false, false
		};
		public boolean isCellEditable(int row, int column) {
			return columnEditables[column];
		}
		
		public int addRow(String fileName,float filesize,int n){
			panelTable=new JPanel();
			panelTable.setLayout(new GridLayout(1,2));
			for(int i=0;i<n;i++){
				pb[i]=new JProgressBar(0,100);
				pb[i].setStringPainted(true);
				//pb[i].setForeground(Color.GREEN);
				//pb[i].setValue(50);
		        //pb[i].setString("complete");
				panelTable.add(pb[i]);
			}
			JButton btn_pause=new JButton("Pause");
			btn_pause.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e){
					System.out.println("*****************************************");
				}
			});
			btn_pause.setBounds(0,0,50,50);
			Object value[]=new Object[]{fileName,panelTable,filesize/1024,"Pause","Cancel"};
			addRow(value);
			return getRowCount();
		}
}

