//Class for downloading a single file as a whole(without segmentation) 

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;


class SingleFileDownload extends Thread{
	BufferedInputStream in;
	BufferedOutputStream os;
	FileOutputStream fs;
	GUI gui;
	String fname;
	String url1;
	
	//constructor
	SingleFileDownload(GUI ui,String filename,String url){
		this.gui=ui;
		this.url1=url;
		//int index=url.lastIndexOf('/');
		//filename=url.substring(index+1);
		fname=filename;
	}
	
	//empty constructor
	SingleFileDownload(){
	}
	
	
	
	//check a target file is already exist or not
	//if file is exist then this function will return unique file name with adding some suffix
	
	
	
	
	//Downloading will be initiating here
    public void run(){
    	try{
    		URL url=new URL(url1);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        long filesize = connection.getContentLength();
	        in=new BufferedInputStream(connection.getInputStream());
	        
	        
	        
	        RandomAccessFile os=new RandomAccessFile(fname,"rw");
	        
	        int readSize=1024*64;
	        byte[] data=new byte[readSize];
	        int i=0;
	        long totalDataRead=0;
	        long percent=0;
	        int row=gui.addDownload(fname,filesize, 1);
	        System.out.println("In run3");
	        while((i=in.read(data,0,readSize))>=0) {
	        
	        	totalDataRead=totalDataRead+i;
	        	os.write(data,0,i);
	        	percent=(totalDataRead*100)/filesize;
	        
	        	gui.updateRow(row,0,(int)percent);
	      
	        	
	       
	        }
	        System.out.println("a");
	        os.close();
	        in.close();
     	}
     	catch(Exception e){
     		System.out.println("Errror: "+e.getMessage());
     	}
     	finally{
     		try{
     			if(in!=null)
     				in.close();
     			
     			if(os!=null)
	        		os.close();
	        		
	        }
	        catch(Exception e){
	        	System.out.println("File Close Error: "+e.getMessage());
	        }
     	}
    }
}

