import java.net.HttpURLConnection;
import java.net.URL;
import java.io.*;
import java.util.*;

class ManageDownload extends Thread{
	GUI gui;
	String fileURL;
	int accelerationFactor;
	Vector<DownloadSegment> segmentList=new Vector<DownloadSegment>();

	ManageDownload(GUI gui,String fileURL,int accelerationFactor){
		this.gui=gui;
		this.fileURL=fileURL;
		this.accelerationFactor=accelerationFactor;
	}

	void changeState(String state){
		Enumeration e = segmentList.elements();
		while(e.hasMoreElements()){
			DownloadSegment obj = (DownloadSegment) e.nextElement();
			obj.changeState(state);
		}
	}

	void cancel(){
		Enumeration e = segmentList.elements();
		while(e.hasMoreElements()){
			DownloadSegment obj = (DownloadSegment) e.nextElement();
			obj.cancel();
		}
	}

	String checkFileExist_return_unique(String filename){
		String sub;
		String ext;
		System.out.println("Before check file exist string = "+ filename);
		int postfix=1;
		int i=filename.lastIndexOf('.');
		System.out.println("i=" + i);
		sub=filename.substring(0, i);
		System.out.println("after substring");
		ext=filename.substring(i+1, filename.length());
		filename=sub.replaceAll("\\W","_");
		ext=ext.replaceAll("\\W","");
		filename=filename+"."+ext;
		System.out.println("Before creating filename");
		File f=new File(filename);
		System.out.println("after creating filename");
		while(f.exists()){
				i=filename.lastIndexOf('.');
				sub=filename.substring(0,i);
				ext=filename.substring(i,filename.length());
				filename=sub+postfix+ext;
				
				postfix++;
				f=new File(filename);
				//System.out.println(sub+" "+postfix+" "+ext);	
		}
		System.out.println(filename);
		return filename;
	}




	public void run(){
		try{
			URL url = new URL(fileURL);
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.connect();

	        if (connection.getResponseCode() != 200) {
	            System.out.println("Error return code != 200");
	        }
	        else{
	        	long contentLength = connection.getContentLength();
	        	connection.disconnect();
	        	
		        connection = (HttpURLConnection) url.openConnection();
		        connection.setRequestProperty("Range", "bytes=" + 0 + "-" + contentLength/2); //is endingByte is empty string http request all the bytes till EOF from given starting byte.
		        connection.connect();
		        
		        String filename=connection.getHeaderField("Content-Disposition");
		       	if(filename==null){
			       	filename=url.getFile();
			    }	        
		      	else if(filename != null && filename.indexOf("=") != -1) {
			 	    filename = filename.split("=")[1]; //getting value after '='
			   	}
			    else
			        filename="file"+connection.getContentType();
			      
			    String fname=checkFileExist_return_unique(filename);

		        if (accelerationFactor==1 || connection.getResponseCode() != 206) {   // http return 206 as signal of OK if request is send with range header
		        	if(connection.getResponseCode() != 206)
		            	System.out.println("Error return code != 206");
		            //server doesn't support byte range
		            //hence we need to download whole file at once;
		            //new DownloadAtOnce(fileURL);
		            System.out.println("inside without accelator factor");
		            //new SingleFileDownload(gui,fname,fileURL).start();
		            

		            int row=gui.addDownload(fname,contentLength,1);
		            DownloadSegment obj = new DownloadSegment(gui,0,-1,fname,fileURL,row,0,true);
		            obj.start();
		            segmentList.add(obj);
		        }
		        else{
		        	System.out.println("inside with accelator factor");
		        	
			        
			        long startingByte=0;
		        	long endingByte;
		        	long segmentSize=contentLength/accelerationFactor;
		        	//if(contentLength<=1024)
		        	//	segmentSize=1024;
		        	endingByte=(contentLength-segmentSize)<=0?contentLength:segmentSize;
		        	int row=gui.addDownload(fname,contentLength,accelerationFactor);
		        	for(int i=0;i<accelerationFactor;i++){
		        		if(contentLength<=startingByte)
		        			break;
		        		if(endingByte==contentLength)
		        			endingByte=-1;

		        		DownloadSegment obj;

		        		if(endingByte==contentLength)
		        			obj=new DownloadSegment(gui,startingByte,-1,fname,fileURL,row,i,false);
		        		else
		        			obj=new DownloadSegment(gui,startingByte,endingByte,fname,fileURL,row,i,false);
		        		obj.start();
		        		segmentList.add(obj);
		        		//else
		        		//	new DownloadSegment(gui,startingByte,endingByte,fname,fileURL,row,i).start();

		        		startingByte=endingByte;
		        		if((endingByte+segmentSize)<=contentLength)
		        			endingByte=endingByte+segmentSize;
		        		else
		        			endingByte=contentLength;
		        	}
		        	
		        }
	        }
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
